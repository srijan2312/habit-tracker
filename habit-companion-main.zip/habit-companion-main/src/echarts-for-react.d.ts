// filepath: c:\Users\srija\Downloads\Compressed\habit-companion-main\habit-companion-main\src\echarts-for-react.d.ts
declare module 'echarts-for-react';