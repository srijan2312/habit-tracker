import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
<<<<<<< HEAD
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, differenceInDays } from 'date-fns';
import { toast } from 'sonner';

export interface Habit {
  id: string;
  user_id: string;
=======
import { useAuth } from '@/contexts/useAuth';
import { format, startOfMonth, endOfMonth, differenceInDays } from 'date-fns';
import { toast } from 'sonner';

export interface Habit {
  _id: string;
  userId: string;
>>>>>>> 7abb816 (Initial commit for GitHub upload)
  title: string;
  description: string | null;
  frequency: string;
  custom_days: number[] | null;
  start_date: string;
  reminder_time: string | null;
  created_at: string;
  updated_at: string;
}

export interface HabitLog {
<<<<<<< HEAD
  id: string;
=======
  _id?: string;
>>>>>>> 7abb816 (Initial commit for GitHub upload)
  habit_id: string;
  user_id: string;
  date: string;
  completed: boolean;
<<<<<<< HEAD
  created_at: string;
=======
  created_at?: string;
>>>>>>> 7abb816 (Initial commit for GitHub upload)
}

export interface HabitWithStats extends Habit {
  currentStreak: number;
  longestStreak: number;
  completionPercentage: number;
  isCompletedToday: boolean;
  logs: HabitLog[];
}

<<<<<<< HEAD
export const useHabits = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const habitsQuery = useQuery({
    queryKey: ['habits', user?.id],
    queryFn: async (): Promise<HabitWithStats[]> => {
      if (!user) return [];

      const { data: habits, error: habitsError } = await supabase
        .from('habits')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (habitsError) throw habitsError;

      const { data: logs, error: logsError } = await supabase
        .from('habit_logs')
        .select('*')
        .eq('user_id', user.id);

      if (logsError) throw logsError;

      const today = format(new Date(), 'yyyy-MM-dd');

      return (habits || []).map((habit) => {
        const habitLogs = (logs || []).filter(log => log.habit_id === habit.id && log.completed);
        const completedDates = habitLogs.map(log => log.date).sort();
        
        // Calculate current streak
        let currentStreak = 0;
        const sortedDates = [...completedDates].sort().reverse();
        const todayCompleted = completedDates.includes(today);
        
        if (todayCompleted || sortedDates.length > 0) {
          let checkDate = new Date();
          if (!todayCompleted) {
            checkDate.setDate(checkDate.getDate() - 1);
          }
          
          for (let i = 0; i < 365; i++) {
            const dateStr = format(checkDate, 'yyyy-MM-dd');
            if (completedDates.includes(dateStr)) {
              currentStreak++;
              checkDate.setDate(checkDate.getDate() - 1);
            } else {
              break;
            }
          }
        }

        // Calculate longest streak
        let longestStreak = 0;
        let tempStreak = 0;
        const allDates = [...completedDates].sort();
        
        for (let i = 0; i < allDates.length; i++) {
          if (i === 0) {
            tempStreak = 1;
          } else {
            const prevDate = new Date(allDates[i - 1]);
            const currDate = new Date(allDates[i]);
            const diff = differenceInDays(currDate, prevDate);
            
            if (diff === 1) {
              tempStreak++;
            } else {
              tempStreak = 1;
            }
          }
          longestStreak = Math.max(longestStreak, tempStreak);
        }

        // Calculate completion percentage (last 30 days)
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        const last30DaysLogs = habitLogs.filter(log => new Date(log.date) >= thirtyDaysAgo);
        const completionPercentage = Math.round((last30DaysLogs.length / 30) * 100);

        return {
          ...habit,
          currentStreak,
          longestStreak,
          completionPercentage,
          isCompletedToday: todayCompleted,
          logs: habitLogs,
        };
      });
=======
interface User {
  _id: string;
  email: string;
}

export const useHabits = () => {
  const auth = useAuth();
  const user = (auth && typeof auth === 'object' && 'user' in auth) ? (auth.user as User | null) : null;
  const queryClient = useQueryClient();

  const habitsQuery = useQuery({
    queryKey: ['habits', user?._id],
    queryFn: async (): Promise<HabitWithStats[]> => {
      if (!user) return [];
      const token = localStorage.getItem('token');
      const res = await fetch(`/api/habits/${user._id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error('Failed to fetch habits');
      // The backend now returns habits with logs and stats
      return await res.json();
>>>>>>> 7abb816 (Initial commit for GitHub upload)
    },
    enabled: !!user,
  });

  const createHabit = useMutation({
    mutationFn: async (habit: Omit<Habit, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => {
      if (!user) throw new Error('Not authenticated');
<<<<<<< HEAD
      
      const { data, error } = await supabase
        .from('habits')
        .insert({
          ...habit,
          user_id: user.id,
        })
        .select()
        .single();

      if (error) throw error;
      return data;
=======
      const token = localStorage.getItem('token');
      const res = await fetch('/api/habits', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ ...habit, userId: user._id }),
      });
      if (!res.ok) throw new Error('Failed to create habit');
      return await res.json();
>>>>>>> 7abb816 (Initial commit for GitHub upload)
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['habits'] });
      toast.success('Habit created successfully!');
    },
<<<<<<< HEAD
    onError: (error) => {
      toast.error('Failed to create habit: ' + error.message);
=======
    onError: (error: unknown) => {
      if (error instanceof Error) {
        toast.error('Failed to create habit: ' + error.message);
      } else {
        toast.error('Failed to create habit');
      }
>>>>>>> 7abb816 (Initial commit for GitHub upload)
    },
  });

  const updateHabit = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<Habit> & { id: string }) => {
<<<<<<< HEAD
      const { data, error } = await supabase
        .from('habits')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
=======
      const token = localStorage.getItem('token');
      const res = await fetch(`/api/habits/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(updates),
      });
      if (!res.ok) throw new Error('Failed to update habit');
      return await res.json();
>>>>>>> 7abb816 (Initial commit for GitHub upload)
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['habits'] });
      toast.success('Habit updated!');
    },
<<<<<<< HEAD
    onError: (error) => {
      toast.error('Failed to update habit: ' + error.message);
=======
    onError: (error: unknown) => {
      if (error instanceof Error) {
        toast.error('Failed to update habit: ' + error.message);
      } else {
        toast.error('Failed to update habit');
      }
>>>>>>> 7abb816 (Initial commit for GitHub upload)
    },
  });

  const deleteHabit = useMutation({
    mutationFn: async (id: string) => {
<<<<<<< HEAD
      const { error } = await supabase
        .from('habits')
        .delete()
        .eq('id', id);

      if (error) throw error;
=======
      const token = localStorage.getItem('token');
      const res = await fetch(`/api/habits/${id}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      if (!res.ok) throw new Error('Failed to delete habit');
>>>>>>> 7abb816 (Initial commit for GitHub upload)
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['habits'] });
      toast.success('Habit deleted');
    },
<<<<<<< HEAD
    onError: (error) => {
      toast.error('Failed to delete habit: ' + error.message);
=======
    onError: (error: unknown) => {
      if (error instanceof Error) {
        toast.error('Failed to delete habit: ' + error.message);
      } else {
        toast.error('Failed to delete habit');
      }
>>>>>>> 7abb816 (Initial commit for GitHub upload)
    },
  });

  const toggleHabitCompletion = useMutation({
    mutationFn: async ({ habitId, date, completed }: { habitId: string; date: string; completed: boolean }) => {
      if (!user) throw new Error('Not authenticated');
<<<<<<< HEAD

      if (completed) {
        // Delete the log
        const { error } = await supabase
          .from('habit_logs')
          .delete()
          .eq('habit_id', habitId)
          .eq('date', date);

        if (error) throw error;
      } else {
        // Create or update the log
        const { error } = await supabase
          .from('habit_logs')
          .upsert({
            habit_id: habitId,
            user_id: user.id,
            date,
            completed: true,
          }, {
            onConflict: 'habit_id,date',
          });

        if (error) throw error;
=======
      const token = localStorage.getItem('token');
      if (completed) {
        // Create the log
        const res = await fetch(`/api/habits/logs`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ habit_id: habitId, user_id: user._id, date, completed: true }),
        });
        if (!res.ok) throw new Error('Failed to create log');
      } else {
        // Delete the log (send user_id as query param for backend compatibility)
        const res = await fetch(`/api/habits/logs/${habitId}/${date}?user_id=${user._id}`, {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.status === 404) {
          toast.error('No log found to untick for this day.');
          return;
        }
        if (!res.ok) throw new Error('Failed to delete log');
>>>>>>> 7abb816 (Initial commit for GitHub upload)
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['habits'] });
    },
<<<<<<< HEAD
    onError: (error) => {
      toast.error('Failed to update habit: ' + error.message);
=======
    onError: (error: unknown) => {
      if (error instanceof Error) {
        toast.error('Failed to update habit: ' + error.message);
      } else {
        toast.error('Failed to update habit');
      }
>>>>>>> 7abb816 (Initial commit for GitHub upload)
    },
  });

  const getMonthLogs = async (month: Date) => {
    if (!user) return [];
<<<<<<< HEAD

    const start = format(startOfMonth(month), 'yyyy-MM-dd');
    const end = format(endOfMonth(month), 'yyyy-MM-dd');

    const { data, error } = await supabase
      .from('habit_logs')
      .select('*')
      .eq('user_id', user.id)
      .gte('date', start)
      .lte('date', end);

    if (error) throw error;
    return data;
=======
    const token = localStorage.getItem('token');
    const start = format(startOfMonth(month), 'yyyy-MM-dd');
    const end = format(endOfMonth(month), 'yyyy-MM-dd');
    const res = await fetch(`/api/habits/logs/${user._id}?start=${start}&end=${end}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) throw new Error('Failed to fetch logs');
    return await res.json();
>>>>>>> 7abb816 (Initial commit for GitHub upload)
  };

  return {
    habits: habitsQuery.data || [],
    isLoading: habitsQuery.isLoading,
    error: habitsQuery.error,
    createHabit,
    updateHabit,
    deleteHabit,
    toggleHabitCompletion,
    getMonthLogs,
    refetch: habitsQuery.refetch,
  };
};
