import { useMemo } from 'react';
import { HabitWithStats } from '@/hooks/useHabits';
import { format, eachDayOfInterval, startOfMonth, endOfMonth, isBefore, isAfter } from 'date-fns';

interface MonthlyProgressRingProps {
  habits: HabitWithStats[];
  selectedMonth: Date;
}

export const MonthlyProgressRing: React.FC<MonthlyProgressRingProps> = ({ 
  habits, 
  selectedMonth 
}) => {
  const { completed, total, percentage } = useMemo(() => {
    const monthStart = startOfMonth(selectedMonth);
    const monthEnd = endOfMonth(selectedMonth);
    const today = new Date();
    const effectiveEnd = isAfter(monthEnd, today) ? today : monthEnd;
    
    const days = eachDayOfInterval({ start: monthStart, end: effectiveEnd });
    const allLogs = habits.flatMap(h => h.logs);
    
    // Count total possible completions (habits * days up to today)
    const totalPossible = habits.length * days.length;
    
    // Count actual completions
    let completedCount = 0;
    days.forEach(day => {
      const dateStr = format(day, 'yyyy-MM-dd');
      const dayCompletions = allLogs.filter(log => log.date === dateStr).length;
      completedCount += dayCompletions;
    });
    
    const pct = totalPossible > 0 ? Math.round((completedCount / totalPossible) * 100) : 0;
    
    return {
      completed: completedCount,
      total: totalPossible,
      percentage: pct,
    };
  }, [habits, selectedMonth]);

  // SVG circle calculations
  const size = 140;
  const strokeWidth = 12;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (percentage / 100) * circumference;

  return (
    <div className="flex flex-col items-center justify-center">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          {/* Background circle */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="hsl(var(--muted))"
            strokeWidth={strokeWidth}
          />
          {/* Progress circle */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="hsl(var(--primary))"
            strokeWidth={strokeWidth}
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            className="transition-all duration-700 ease-out"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-2xl font-bold text-foreground">{completed} / {total}</span>
        </div>
      </div>
      <p className="mt-2 text-sm font-medium text-muted-foreground">
        {percentage}% Complete
      </p>
    </div>
  );
};
