import { useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { HabitWithStats } from '@/hooks/useHabits';
import { format, eachDayOfInterval, startOfMonth, endOfMonth, isBefore, isAfter } from 'date-fns';

interface MonthlyProgressChartProps {
  habits: HabitWithStats[];
  selectedMonth: Date;
  type: 'daily' | 'cumulative';
}

export const MonthlyProgressChart: React.FC<MonthlyProgressChartProps> = ({ 
  habits, 
  selectedMonth,
  type 
}) => {
  const chartData = useMemo(() => {
    const monthStart = startOfMonth(selectedMonth);
    const monthEnd = endOfMonth(selectedMonth);
    const today = new Date();
    const effectiveEnd = isAfter(monthEnd, today) ? today : monthEnd;
    
    const days = eachDayOfInterval({ start: monthStart, end: effectiveEnd });
    
    // Collect all logs from all habits
    const allLogs = habits.flatMap(h => h.logs);
    
    let cumulative = 0;
    
    return days.map(day => {
      const dateStr = format(day, 'yyyy-MM-dd');
      const dayNum = format(day, 'd');
      
      // Count completed habits for this day
      const completedCount = allLogs.filter(log => log.date === dateStr).length;
      const totalHabits = habits.length;
      const percentage = totalHabits > 0 ? Math.round((completedCount / totalHabits) * 100) : 0;
      
      cumulative += completedCount;
      
      return {
        day: dayNum,
        date: dateStr,
        completed: completedCount,
        percentage,
        cumulative,
      };
    });
  }, [habits, selectedMonth]);

  if (habits.length === 0) {
    return (
      <div className="flex h-full items-center justify-center text-muted-foreground">
        No habits to display
      </div>
    );
  }

  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
        <defs>
          <linearGradient id="colorProgress" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
            <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
        <XAxis 
          dataKey="day" 
          tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }}
          axisLine={{ stroke: 'hsl(var(--border))' }}
          tickLine={{ stroke: 'hsl(var(--border))' }}
        />
        <YAxis 
          tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }}
          axisLine={{ stroke: 'hsl(var(--border))' }}
          tickLine={{ stroke: 'hsl(var(--border))' }}
          tickFormatter={(value) => type === 'daily' ? `${value}%` : value}
        />
        <Tooltip 
          contentStyle={{ 
            backgroundColor: 'hsl(var(--card))',
            border: '1px solid hsl(var(--border))',
            borderRadius: '8px',
            fontSize: '12px',
          }}
          labelFormatter={(label, payload) => {
            if (payload && payload[0]) {
              return format(new Date(payload[0].payload.date), 'MMM d, yyyy');
            }
            return label;
          }}
          formatter={(value: number) => [
            type === 'daily' ? `${value}%` : value,
            type === 'daily' ? 'Completion' : 'Total Completed'
          ]}
        />
        <Area
          type="monotone"
          dataKey={type === 'daily' ? 'percentage' : 'cumulative'}
          stroke="hsl(var(--primary))"
          strokeWidth={2}
          fill="url(#colorProgress)"
        />
      </AreaChart>
    </ResponsiveContainer>
  );
};
