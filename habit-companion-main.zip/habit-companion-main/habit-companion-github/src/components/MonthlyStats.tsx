import { useMemo } from 'react';
import { CheckCircle2, XCircle } from 'lucide-react';
import { HabitWithStats } from '@/hooks/useHabits';
import { format, eachDayOfInterval, startOfMonth, endOfMonth, isAfter } from 'date-fns';

interface MonthlyStatsProps {
  habits: HabitWithStats[];
  selectedMonth: Date;
}

export const MonthlyStats: React.FC<MonthlyStatsProps> = ({ habits, selectedMonth }) => {
  const stats = useMemo(() => {
    const monthStart = startOfMonth(selectedMonth);
    const monthEnd = endOfMonth(selectedMonth);
    const today = new Date();
    const effectiveEnd = isAfter(monthEnd, today) ? today : monthEnd;
    
    const days = eachDayOfInterval({ start: monthStart, end: effectiveEnd });
    const allLogs = habits.flatMap(h => h.logs);
    
    // Count total possible completions
    const totalPossible = habits.length * days.length;
    
    // Count actual completions
    let completedCount = 0;
    days.forEach(day => {
      const dateStr = format(day, 'yyyy-MM-dd');
      const dayCompletions = allLogs.filter(log => log.date === dateStr).length;
      completedCount += dayCompletions;
    });
    
    const uncompleted = totalPossible - completedCount;
    
    return {
      completed: completedCount,
      uncompleted,
      total: totalPossible,
    };
  }, [habits, selectedMonth]);

  return (
    <div className="space-y-4">
      <div className="flex items-start gap-3">
        <div className="rounded-lg bg-success/10 p-2">
          <CheckCircle2 className="h-5 w-5 text-success" />
        </div>
        <div>
          <p className="text-sm font-medium text-success">Total Habits Completed</p>
          <p className="text-4xl font-bold text-foreground">{stats.completed}</p>
        </div>
      </div>
      
      <div className="flex items-start gap-3">
        <div className="rounded-lg bg-destructive/10 p-2">
          <XCircle className="h-5 w-5 text-destructive" />
        </div>
        <div>
          <p className="text-sm font-medium text-destructive">Total Habits Uncompleted</p>
          <p className="text-4xl font-bold text-foreground">{stats.uncompleted}</p>
        </div>
      </div>
    </div>
  );
};
