import { useMemo } from 'react';
<<<<<<< HEAD
import { Target, Flame, Trophy, TrendingUp } from 'lucide-react';
=======
import { Target, Flame, Trophy, TrendingUp, Star } from 'lucide-react';
>>>>>>> 7abb816 (Initial commit for GitHub upload)
import { HabitWithStats } from '@/hooks/useHabits';
import { format } from 'date-fns';

interface StatsOverviewProps {
  habits: HabitWithStats[];
}

export const StatsOverview: React.FC<StatsOverviewProps> = ({ habits }) => {
  const today = format(new Date(), 'yyyy-MM-dd');

  const stats = useMemo(() => {
    const totalHabits = habits.length;
    const completedToday = habits.filter(h => h.isCompletedToday).length;
    const totalCurrentStreak = habits.reduce((sum, h) => sum + h.currentStreak, 0);
    const bestStreak = Math.max(...habits.map(h => h.longestStreak), 0);
    const avgCompletion = totalHabits > 0 
      ? Math.round(habits.reduce((sum, h) => sum + h.completionPercentage, 0) / totalHabits)
      : 0;

<<<<<<< HEAD
=======
    // Most Consistent Habit (highest completion % this month)
    let mostConsistentHabit = null;
    if (habits.length > 0) {
      mostConsistentHabit = habits.reduce((max, h) =>
        (h.completionPercentage > (max?.completionPercentage ?? -1) ? h : max), null
      );
    }

>>>>>>> 7abb816 (Initial commit for GitHub upload)
    return {
      totalHabits,
      completedToday,
      pendingToday: totalHabits - completedToday,
      totalCurrentStreak,
      bestStreak,
      avgCompletion,
<<<<<<< HEAD
=======
      mostConsistentHabit,
>>>>>>> 7abb816 (Initial commit for GitHub upload)
    };
  }, [habits]);

  const cards = [
    {
      title: "Today's Progress",
      value: `${stats.completedToday}/${stats.totalHabits}`,
      subtitle: `${stats.pendingToday} habits pending`,
      icon: Target,
      color: 'text-primary',
      bgColor: 'bg-primary/10',
    },
    {
<<<<<<< HEAD
      title: 'Active Streaks',
      value: stats.totalCurrentStreak,
      subtitle: 'Combined days',
      icon: Flame,
      color: 'text-streak',
      bgColor: 'bg-streak/10',
    },
    {
=======
>>>>>>> 7abb816 (Initial commit for GitHub upload)
      title: 'Best Streak',
      value: `${stats.bestStreak} days`,
      subtitle: 'Personal record',
      icon: Trophy,
      color: 'text-warning',
      bgColor: 'bg-warning/10',
    },
<<<<<<< HEAD
=======
    stats.mostConsistentHabit && {
      title: 'Most Consistent Habit',
      value: stats.mostConsistentHabit.title,
      subtitle: `${Math.round(stats.mostConsistentHabit.completionPercentage)}% this month`,
      icon: Star,
      color: 'text-accent',
      bgColor: 'bg-accent/10',
    },
>>>>>>> 7abb816 (Initial commit for GitHub upload)
    {
      title: 'Avg. Completion',
      value: `${stats.avgCompletion}%`,
      subtitle: 'Last 30 days',
      icon: TrendingUp,
      color: 'text-success',
      bgColor: 'bg-success/10',
    },
  ];

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
<<<<<<< HEAD
      {cards.map((card, index) => (
=======
      {cards.filter(Boolean).map((card, index) => (
>>>>>>> 7abb816 (Initial commit for GitHub upload)
        <div
          key={card.title}
          className="group rounded-xl border bg-card p-5 transition-all duration-300 hover:shadow-lg animate-fade-up"
          style={{ animationDelay: `${index * 100}ms` }}
        >
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground">{card.title}</p>
              <p className="mt-1 text-3xl font-bold tracking-tight text-foreground">
                {card.value}
              </p>
              <p className="mt-1 text-xs text-muted-foreground">{card.subtitle}</p>
            </div>
            <div className={`rounded-lg p-2.5 ${card.bgColor}`}>
              <card.icon className={`h-5 w-5 ${card.color}`} />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
