import { Link, useNavigate } from 'react-router-dom';
import { LogOut, User, Leaf, Menu, X } from 'lucide-react';
<<<<<<< HEAD
import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
=======
import { ThemeToggle } from './ThemeToggle';
import { QuickAddHabitButton } from './QuickAddHabitButton';
import { SearchBar } from './SearchBar';
import { MotivationalQuote } from './MotivationalQuote';
import HabitFormModal from './HabitFormModal';
import { useState } from 'react';
import { useAuth } from '@/contexts/useAuth';
>>>>>>> 7abb816 (Initial commit for GitHub upload)
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

export const Header: React.FC = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
<<<<<<< HEAD
=======
  const [showHabitModal, setShowHabitModal] = useState(false);
>>>>>>> 7abb816 (Initial commit for GitHub upload)

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

<<<<<<< HEAD
=======
  // For demo: just alert search
  const handleSearch = (query: string) => {
    if (query) alert(`Search for: ${query}`);
  };

>>>>>>> 7abb816 (Initial commit for GitHub upload)
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-card/80 backdrop-blur-md">
      <div className="container flex h-16 items-center justify-between">
        <Link to={user ? '/dashboard' : '/'} className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
            <Leaf className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="font-display text-xl font-bold text-foreground">
            Habitly
          </span>
        </Link>

<<<<<<< HEAD
        {user ? (
          <>
            {/* Desktop Navigation */}
            <nav className="hidden items-center gap-6 md:flex">
              <Link 
                to="/dashboard" 
                className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
              >
                Dashboard
              </Link>
              <Link 
                to="/monthly" 
                className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
              >
                Monthly Tracker
              </Link>
              <Link 
                to="/calendar" 
                className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
              >
                Calendar
              </Link>
            </nav>

            <div className="flex items-center gap-4">
=======
        {/* Centered Menu */}
        {user && (
          <nav className="hidden md:flex absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 items-center gap-10">
            <Link 
              to="/dashboard" 
              className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
            >
              Dashboard
            </Link>
            <Link 
              to="/monthly-tracker" 
              className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
            >
              Monthly Tracker
            </Link>
            <Link 
              to="/calendar" 
              className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
            >
              Calendar
            </Link>
          </nav>
        )}

        {/* Right side: ThemeToggle, Profile */}
        <div className="flex items-center gap-6">
          <ThemeToggle />
          {user ? (
            <>
>>>>>>> 7abb816 (Initial commit for GitHub upload)
              {/* Desktop User Menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild className="hidden md:flex">
                  <Button variant="ghost" className="gap-2">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                      <User className="h-4 w-4 text-primary" />
                    </div>
                    <span className="max-w-[150px] truncate text-sm">
                      {user.email}
                    </span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem onClick={handleSignOut} className="text-destructive">
                    <LogOut className="mr-2 h-4 w-4" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
<<<<<<< HEAD

=======
>>>>>>> 7abb816 (Initial commit for GitHub upload)
              {/* Mobile Menu Button */}
              <Button 
                variant="ghost" 
                size="icon"
                className="md:hidden"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </Button>
<<<<<<< HEAD
            </div>

            {/* Mobile Menu */}
            {mobileMenuOpen && (
              <div className="absolute left-0 top-16 w-full border-b bg-card p-4 md:hidden">
                <nav className="flex flex-col gap-4">
                  <Link 
                    to="/dashboard" 
                    className="text-sm font-medium"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Dashboard
                  </Link>
                  <Link 
                    to="/monthly" 
                    className="text-sm font-medium"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Monthly Tracker
                  </Link>
                  <Link 
                    to="/calendar" 
                    className="text-sm font-medium"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Calendar
                  </Link>
                  <hr className="border-border" />
                  <button 
                    onClick={handleSignOut}
                    className="flex items-center gap-2 text-sm font-medium text-destructive"
                  >
                    <LogOut className="h-4 w-4" />
                    Sign Out
                  </button>
                </nav>
              </div>
            )}
          </>
        ) : (
          <div className="flex items-center gap-3">
            <Button variant="ghost" asChild>
              <Link to="/signin">Sign In</Link>
            </Button>
            <Button asChild>
              <Link to="/signup">Get Started</Link>
            </Button>
          </div>
        )}
      </div>
=======
              {/* Mobile Menu */}
              {mobileMenuOpen && (
                <div className="absolute left-0 top-16 w-full border-b bg-card p-4 md:hidden">
                  <nav className="flex flex-col gap-4">
                    <Link 
                      to="/dashboard" 
                      className="text-sm font-medium"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      Dashboard
                    </Link>
                    <Link 
                      to="/monthly-tracker" 
                      className="text-sm font-medium"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      Monthly Tracker
                    </Link>
                    <Link 
                      to="/calendar" 
                      className="text-sm font-medium"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      Calendar
                    </Link>
                    <hr className="border-border" />
                    <button 
                      onClick={handleSignOut}
                      className="flex items-center gap-2 text-sm font-medium text-destructive"
                    >
                      <LogOut className="h-4 w-4" />
                      Sign Out
                    </button>
                  </nav>
                </div>
              )}
            </>
          ) : (
            <>
              <Button variant="ghost" asChild>
                <Link to="/signin">Sign In</Link>
              </Button>
              <Button asChild>
                <Link to="/signup">Get Started</Link>
              </Button>
            </>
          )}
        </div>
      </div>
      {/* Quick Add Habit Modal */}
      <HabitFormModal open={showHabitModal} onClose={() => setShowHabitModal(false)} onSubmit={() => setShowHabitModal(false)} />
>>>>>>> 7abb816 (Initial commit for GitHub upload)
    </header>
  );
};
