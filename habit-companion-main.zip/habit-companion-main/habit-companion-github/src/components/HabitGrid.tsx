import { useMemo } from 'react';
import { Check } from 'lucide-react';
import { HabitWithStats } from '@/hooks/useHabits';
import { format, eachDayOfInterval, startOfMonth, endOfMonth, getDay, isBefore, isAfter, startOfDay } from 'date-fns';
import { cn } from '@/lib/utils';

interface HabitGridProps {
  habits: HabitWithStats[];
  selectedMonth: Date;
  onToggle: (habitId: string, date: string, currentlyCompleted: boolean) => void;
}

export const HabitGrid: React.FC<HabitGridProps> = ({ 
  habits, 
  selectedMonth,
  onToggle 
}) => {
  const { days, weeks } = useMemo(() => {
    const monthStart = startOfMonth(selectedMonth);
    const monthEnd = endOfMonth(selectedMonth);
    const allDays = eachDayOfInterval({ start: monthStart, end: monthEnd });
    
    // Group days by week
    const weekGroups: Date[][] = [];
    let currentWeek: Date[] = [];
    
    allDays.forEach((day, index) => {
      currentWeek.push(day);
      if (getDay(day) === 6 || index === allDays.length - 1) {
        weekGroups.push([...currentWeek]);
        currentWeek = [];
      }
    });
    
    return { days: allDays, weeks: weekGroups };
  }, [selectedMonth]);

  const habitStats = useMemo(() => {
    return habits.map(habit => {
      const monthStart = startOfMonth(selectedMonth);
      const monthEnd = endOfMonth(selectedMonth);
      const today = new Date();
      const effectiveEnd = isAfter(monthEnd, today) ? today : monthEnd;
      
      const daysInRange = eachDayOfInterval({ start: monthStart, end: effectiveEnd });
      const completedDays = habit.logs.filter(log => {
        const logDate = new Date(log.date);
        return logDate >= monthStart && logDate <= effectiveEnd;
      }).length;
      
      const totalDays = daysInRange.length;
      const percentage = totalDays > 0 ? Math.round((completedDays / totalDays) * 100) : 0;
      
      return {
        habitId: habit.id,
        completedDays,
        totalDays,
        percentage,
      };
    });
  }, [habits, selectedMonth]);

  const isDateCompleted = (habitId: string, date: Date) => {
    const habit = habits.find(h => h.id === habitId);
    if (!habit) return false;
    const dateStr = format(date, 'yyyy-MM-dd');
    return habit.logs.some(log => log.date === dateStr);
  };

  const isFutureDate = (date: Date) => {
    return isAfter(startOfDay(date), startOfDay(new Date()));
  };

  const dayLabels = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
  const today = format(new Date(), 'yyyy-MM-dd');

  if (habits.length === 0) {
    return (
      <div className="flex h-64 items-center justify-center rounded-lg border bg-card text-muted-foreground">
        No habits to track. Create your first habit to get started!
      </div>
    );
  }

  return (
    <div className="overflow-x-auto rounded-lg border bg-card">
      <table className="w-full min-w-[800px] border-collapse text-sm">
        <thead>
          <tr className="border-b bg-muted/50">
            <th className="sticky left-0 z-10 bg-muted/50 px-4 py-3 text-left font-semibold text-foreground">
              <div className="flex items-center gap-2">
                <span className="w-8 text-center text-xs text-muted-foreground">S/N</span>
                <span>HABITS</span>
              </div>
            </th>
            {weeks.map((week, weekIndex) => (
              <th 
                key={weekIndex} 
                colSpan={week.length}
                className="border-l px-2 py-1 text-center text-xs font-semibold text-primary"
              >
                WEEK {weekIndex + 1}
              </th>
            ))}
            <th className="border-l px-3 py-3 text-center text-xs font-semibold text-foreground">
              TASKS<br/>COMPLETED
            </th>
            <th className="border-l px-3 py-3 text-center text-xs font-semibold text-foreground">
              TOTAL
            </th>
          </tr>
          <tr className="border-b bg-muted/30">
            <th className="sticky left-0 z-10 bg-muted/30 px-4 py-2"></th>
            {days.map((day) => {
              const dayOfWeek = getDay(day);
              const dateStr = format(day, 'yyyy-MM-dd');
              const isToday = dateStr === today;
              return (
                <th 
                  key={dateStr}
                  className={cn(
                    "border-l px-1 py-1 text-center",
                    isToday && "bg-primary/20"
                  )}
                >
                  <div className="flex flex-col items-center gap-0.5">
                    <span className="text-[10px] text-muted-foreground">{dayLabels[dayOfWeek]}</span>
                    <span className={cn(
                      "text-xs font-medium",
                      isToday ? "text-primary font-bold" : "text-foreground"
                    )}>
                      {format(day, 'd')}
                    </span>
                  </div>
                </th>
              );
            })}
            <th className="border-l px-3 py-2"></th>
            <th className="border-l px-3 py-2"></th>
          </tr>
        </thead>
        <tbody>
          {habits.map((habit, index) => {
            const stats = habitStats.find(s => s.habitId === habit.id);
            return (
              <tr key={habit.id} className="border-b hover:bg-muted/20 transition-colors">
                <td className="sticky left-0 z-10 bg-card px-4 py-3">
                  <div className="flex items-center gap-2">
                    <span className="w-8 text-center font-bold text-primary">{index + 1}</span>
                    <span className="font-medium text-foreground truncate max-w-[150px]" title={habit.title}>
                      {habit.title}
                    </span>
                  </div>
                </td>
                {days.map((day) => {
                  const dateStr = format(day, 'yyyy-MM-dd');
                  const isCompleted = isDateCompleted(habit.id, day);
                  const isFuture = isFutureDate(day);
                  const isToday = dateStr === today;
                  
                  return (
                    <td 
                      key={dateStr}
                      className={cn(
                        "border-l px-1 py-2 text-center",
                        isToday && "bg-primary/10"
                      )}
                    >
                      <button
                        onClick={() => !isFuture && onToggle(habit.id, dateStr, isCompleted)}
                        disabled={isFuture}
                        className={cn(
                          "mx-auto flex h-6 w-6 items-center justify-center rounded border-2 transition-all",
                          isCompleted 
                            ? "border-primary bg-primary text-primary-foreground" 
                            : "border-muted-foreground/30 bg-background hover:border-primary/50",
                          isFuture && "opacity-30 cursor-not-allowed"
                        )}
                      >
                        {isCompleted && <Check className="h-4 w-4" />}
                      </button>
                    </td>
                  );
                })}
                <td className="border-l px-3 py-3 text-center">
                  <span className="font-semibold text-foreground">
                    {stats?.completedDays} / {stats?.totalDays}
                  </span>
                </td>
                <td className="border-l px-3 py-3 text-center">
                  <div 
                    className="mx-auto h-6 rounded px-3 flex items-center justify-center text-sm font-bold text-white"
                    style={{
                      backgroundColor: `hsl(${280 + (stats?.percentage || 0) * 0.8}, 70%, 50%)`,
                      minWidth: '50px',
                    }}
                  >
                    {stats?.percentage}%
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};
