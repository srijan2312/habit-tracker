<<<<<<< HEAD
import { useState } from 'react';
import { Check, Flame, MoreHorizontal, Pencil, Trash2, Calendar } from 'lucide-react';
=======
import { Flame, MoreHorizontal, Pencil, Trash2, Calendar } from 'lucide-react';
>>>>>>> 7abb816 (Initial commit for GitHub upload)
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { HabitWithStats } from '@/hooks/useHabits';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Progress } from '@/components/ui/progress';

<<<<<<< HEAD
interface HabitCardProps {
  habit: HabitWithStats;
  onToggle: (habitId: string, date: string, completed: boolean) => void;
=======
import { useNavigate } from 'react-router-dom';

interface HabitCardProps {
  habit: HabitWithStats;
>>>>>>> 7abb816 (Initial commit for GitHub upload)
  onEdit: (habit: HabitWithStats) => void;
  onDelete: (habitId: string) => void;
}

export const HabitCard: React.FC<HabitCardProps> = ({
  habit,
<<<<<<< HEAD
  onToggle,
  onEdit,
  onDelete,
}) => {
  const [isAnimating, setIsAnimating] = useState(false);
  const today = format(new Date(), 'yyyy-MM-dd');

  const handleToggle = () => {
    if (!habit.isCompletedToday) {
      setIsAnimating(true);
      setTimeout(() => setIsAnimating(false), 400);
    }
    onToggle(habit.id, today, habit.isCompletedToday);
  };
=======
  onEdit,
  onDelete,
}) => {
  const navigate = useNavigate();
  // Calculate days in current month
  const now = new Date();
  const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0);
  const daysInMonth = monthEnd.getDate();
>>>>>>> 7abb816 (Initial commit for GitHub upload)

  const frequencyLabel = habit.frequency === 'daily' 
    ? 'Daily' 
    : habit.frequency === 'weekly' 
      ? 'Weekly' 
      : 'Custom';

<<<<<<< HEAD
  return (
    <div 
      className={cn(
        "group relative overflow-hidden rounded-xl border bg-card p-5 transition-all duration-300 hover:shadow-lg",
        habit.isCompletedToday && "border-success/30 bg-success-light/30"
      )}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-4">
          {/* Completion Button */}
          <button
            onClick={handleToggle}
            className={cn(
              "relative flex h-10 w-10 shrink-0 items-center justify-center rounded-full border-2 transition-all duration-300",
              habit.isCompletedToday
                ? "border-success bg-success text-primary-foreground"
                : "border-muted-foreground/30 hover:border-primary hover:bg-primary/5"
            )}
          >
            {habit.isCompletedToday && (
              <Check 
                className={cn(
                  "h-5 w-5",
                  isAnimating && "animate-check"
                )} 
              />
            )}
          </button>

          {/* Habit Info */}
          <div className="flex flex-col gap-1">
            <h3 className={cn(
              "font-semibold text-foreground transition-all",
              habit.isCompletedToday && "line-through opacity-60"
            )}>
              {habit.title}
            </h3>
=======
  // When card is clicked, go to monthly planner for this habit
  const handleCardClick = () => {
    navigate(`/monthly-tracker?habitId=${habit._id}`);
  };

  return (
    <div 
      className={cn(
        "group relative overflow-hidden rounded-xl border bg-card p-5 transition-all duration-300 hover:shadow-lg cursor-pointer",
        habit.isCompletedToday && "border-success/30 bg-success-light/30"
      )}
      onClick={handleCardClick}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-4">
          {/* Removed tick/untick button. Card is now clickable. */}

          {/* Habit Info */}
          <div className="flex flex-col gap-1">
              <h3 className={cn(
                "font-semibold text-foreground transition-all"
              )}>
                {habit.title}
              </h3>
>>>>>>> 7abb816 (Initial commit for GitHub upload)
            {habit.description && (
              <p className="text-sm text-muted-foreground line-clamp-2">
                {habit.description}
              </p>
            )}
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1 rounded-full bg-secondary px-2.5 py-0.5 text-xs font-medium text-secondary-foreground">
                <Calendar className="h-3 w-3" />
                {frequencyLabel}
              </span>
              {habit.currentStreak > 0 && (
                <span className={cn(
                  "inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium",
                  habit.currentStreak >= 7 
                    ? "bg-streak-light text-streak animate-streak" 
                    : "bg-warning-light text-warning"
                )}>
                  <Flame className="h-3 w-3" />
                  {habit.currentStreak} day streak
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Actions */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button 
              variant="ghost" 
              size="icon" 
<<<<<<< HEAD
              className="h-8 w-8 opacity-0 transition-opacity group-hover:opacity-100"
=======
              className="h-8 w-8 bg-secondary text-foreground shadow-none"
>>>>>>> 7abb816 (Initial commit for GitHub upload)
            >
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
<<<<<<< HEAD
            <DropdownMenuItem onClick={() => onEdit(habit)}>
=======
            <DropdownMenuItem onClick={e => { e.stopPropagation(); onEdit(habit); }}>
>>>>>>> 7abb816 (Initial commit for GitHub upload)
              <Pencil className="mr-2 h-4 w-4" />
              Edit
            </DropdownMenuItem>
            <DropdownMenuItem 
<<<<<<< HEAD
              onClick={() => onDelete(habit.id)}
=======
              onClick={e => { e.stopPropagation(); onDelete(habit._id); }}
>>>>>>> 7abb816 (Initial commit for GitHub upload)
              className="text-destructive focus:text-destructive"
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Progress Bar */}
      <div className="mt-4 space-y-1.5">
        <div className="flex items-center justify-between text-xs">
<<<<<<< HEAD
          <span className="text-muted-foreground">30-day progress</span>
          <span className="font-medium text-foreground">{habit.completionPercentage}%</span>
        </div>
        <Progress value={habit.completionPercentage} className="h-1.5" />
=======
          <span className="text-muted-foreground">{daysInMonth} day progress</span>
          <span className="font-medium text-foreground">{Math.min(habit.completionPercentage, 100)}%</span>
        </div>
        <Progress value={Math.min(habit.completionPercentage, 100)} className="h-1.5" />
>>>>>>> 7abb816 (Initial commit for GitHub upload)
      </div>

      {/* Stats */}
      <div className="mt-4 grid grid-cols-2 gap-3 border-t pt-4">
        <div className="text-center">
          <p className="text-2xl font-bold text-primary">{habit.currentStreak}</p>
          <p className="text-xs text-muted-foreground">Current Streak</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-bold text-foreground">{habit.longestStreak}</p>
          <p className="text-xs text-muted-foreground">Best Streak</p>
        </div>
      </div>
    </div>
  );
};
